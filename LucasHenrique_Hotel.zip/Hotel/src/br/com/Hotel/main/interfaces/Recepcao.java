package br.com.Hotel.main.interfaces;


public interface Recepcao {
	
	String acessarRecepcao();

}
