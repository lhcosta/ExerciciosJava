
public class Agencia extends Setor {

	@Override
	public void acessar(Pessoa pessoa) {
		//Todos possuem acesso a agencia
	}
	
	
	
	
}
