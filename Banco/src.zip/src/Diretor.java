
public class Diretor extends Pessoa {

	Diretor(String login) {
		super(login);
		// TODO Auto-generated constructor stub
	}

}
