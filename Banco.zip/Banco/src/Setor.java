

public abstract class Setor {
	
	public abstract void acessar(Pessoa pessoa);
	
}
