package br.com.Hotel.main.interfaces;


public interface Limpeza {
	
	String acessarLimpeza();
}
