package br.com.Hotel.main;
import br.com.Hotel.utils.Menu;

/*
 * LUCAS HENRIQUE - UC17201125
 * 
 * Esse sistema consiste em auxiliar no cadastramento de funcionarios (Gerente, Servicais, Recepcionista, Porteiro, Cozinheiro) em um hotel
 * e também cadastrar hospédes, é possível fazer a listagem de todos os funcionários com os seus respectivos cargos e listar os hóspedes, também
 * realizar o controle de acesso de certos funcionários em alguns setores do hotel, como por exemplo: só é permitido a entrada de cozinheiros na
 * cozinha.
 */

public class Executer {
	
	public static void main(String[] args) {
		 
		Menu.principal();
	}
	
}
