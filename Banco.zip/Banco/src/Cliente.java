
public class Cliente extends Pessoa {

	Cliente(String login) {
		super(login);
	}
	
	
	
	
}
