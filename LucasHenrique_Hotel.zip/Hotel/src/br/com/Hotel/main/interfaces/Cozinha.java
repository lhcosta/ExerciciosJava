package br.com.Hotel.main.interfaces;

public interface Cozinha {
	
	String acessarCozinha();
}
