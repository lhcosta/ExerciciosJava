
public class Gerente extends Pessoa {

	Gerente(String login) {
		super(login);
		// TODO Auto-generated constructor stub
	}

	
}
