package br.com.Hospital.main.interfaces;

public interface SalaCirurgia {
	
	public String realizarCirurgia();

}
