
public class Funcionario extends Pessoa{

	Funcionario(String login) {
		super(login);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
